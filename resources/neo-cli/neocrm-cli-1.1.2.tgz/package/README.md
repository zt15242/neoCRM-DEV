# neocrm-cli

> 想快速了解整套工具的能力边界、典型工作流与安全使用方式，请阅读：[能力介绍与使用说明](./能力介绍与使用说明.md)。

**Neo 开发助手**——一套让你在 AI 编辑器（Kiro / Cursor / Claude Code / CodeBuddy / WorkBuddy 等）里，用自然语言完成 NeoCRM PaaS 平台前后端定制开发的工具链。`neo` 是唯一正式 CLI 命令，对标 Salesforce CLI，以本地文件为「真源」在本地与租户间双向同步元数据；项目级 `neocrm-platform` 代理使用当前项目登录态连接服务端 MCP；本地 source 和租户元数据写入只由 CLI 完成。

> 内部目录 `skills/ncli-based-skills/` 暂不重命名，仅用于源码分类，不代表可执行命令或兼容别名。

---

## 总览：整套工具

Neo 开发助手由三层协作，装一个包即全部到位：

```
┌─────────────────────────────────────────────────────────────┐
│  AI 编辑器（Kiro / Cursor / Claude / CodeBuddy / WorkBuddy）  │
│      用自然语言描述需求，AI 按需调用下面三层能力              │
└───────────────┬───────────────────────────┬─────────────────┘
                │                           │
        ┌───────▼────────┐          ┌───────▼────────┐
        │  Skills 技能包  │          │ 平台 MCP 服务 │
        │ 平台知识+工作流 │          │ neocrm-platform│
        │ 动态分发、按需  │          │ 代理（当前项目 │
        │ 装入编辑器      │          │ 登录态）       │
        └───────┬────────┘          └───────┬────────┘
                └───────────┬───────────────┘
                    ┌───────▼────────┐
                    │  neo CLI        │  source-driven 元数据开发
                    │ (neocrm-cli)    │  建项目/登录/生成/部署/检索
                    └───────┬────────┘
                    ┌───────▼────────┐
                    │  NeoCRM 租户    │  REST / Metadata API
                    └────────────────┘
```

| 层 | 组件 | 作用 |
|---|---|---|
| 命令行 | **neo CLI**（`neocrm-cli`，唯一正式命令 `neo`） | source-driven 的元数据开发工具：项目、登录、对象/字段/业务类型、UI 组件、NEX、后端代码包的本地生成与租户双向同步（本文主体） |
| 工具协议 | **neocrm-platform** | 项目级 stdio 代理，使用当前项目登录态访问服务端 NeoCRM 平台 MCP |

**关键特性**
- **Source-driven**：本地文件是真源，`generate`/`deploy`/`retrieve` 在本地与租户间双向同步，变更可 git diff / 评审 / 回滚。
- **凭证隔离**：登录 token 存全局区 `~/.neocrm-cli/auth/`（0600），**不落项目目录**；CLI 与平台 MCP 代理共用同一次 `neo login`。
- **AI 原生**：服务端 MCP 的能力由平台统一维护；本地 source 和租户写入经审查后的 CLI 完成。

### 快速安装

下载对应平台的安装包安装（macOS `.pkg` 双击，或 zip 解压后跑一键脚本），前置 Node.js ≥ 16，装完 `neo -v` 验证。详见 [下方「安装」](#安装)。从源码构建见 [开发](#开发)。

### 5 分钟上手

```bash
neo init -n my-project        # 建项目骨架并生成 CodeBuddy .mcp.json
cd my-project
neo login -e sandbox          # OAuth2 授权租户（凭证存全局区，不入项目）
neo list object --custom      # 看租户有哪些自定义实体
neo describe object --api-key account --md   # 查客户实体字段字典
neo generate object --api-key project --label 项目   # 本地生成对象源
neo deploy object --api-key project__c --dry-run   # 先预演
neo deploy object --api-key project__c --confirm   # 审查后实际部署
```

配置 MCP 后，直接对 AI 说「查一下 account 有哪些字段」「帮我做一个商机看板组件」即可，AI 会自动调用相应技能与工具。

**V1 覆盖范围（P0）**：自定义对象、自定义字段、实体业务类型、UI 组件、NEX 标准页面扩展、后端代码包。表达式校验入口为 `neo validate expression`；公式字段和实体汇总字段仅在安装并精确匹配已验证目标契约时可远端部署，当前无契约时明确 fail-closed。

---

## 目录

- [总览：整套工具](#总览整套工具)

- [安装](#安装)
- [核心概念](#核心概念)
- [快速上手](#快速上手)
- [命令总览](#命令总览)
- [命令详解与参数说明](#命令详解与参数说明)
  - [neo init](#neo-init)
  - [neo login / logout / loginstatus](#neo-login--logout--loginstatus)
  - [neo generate](#neo-generate)
  - [neo deploy](#neo-deploy)
  - [neo retrieve](#neo-retrieve)
  - [neo list](#neo-list)
  - [neo query](#neo-query)
  - [NEX 页面扩展](#nex-页面扩展)
  - [后端代码包 codepackage](#后端代码包-codepackage)
- [匿名使用统计（telemetry）](#匿名使用统计telemetry)
- [字段类型](#字段类型)
- [部署行为](#部署行为)
- [UI 组件：源码与构建分离](#ui-组件源码与构建分离)
- [已确认的平台 API（P0）](#已确认的平台-apip0)
- [开发](#开发)

---

## 安装

下载对应平台的安装包安装。前置：目标机已装 **Node.js ≥ 16**。

| 方式 | 平台 | 步骤 |
|---|---|---|
| `.pkg` 图形安装 | macOS | 双击 `neocrm-cli-<ver>-darwin-<arch>.pkg` → 按向导。包已使用 Developer ID Installer 签名，装到 `/usr/local/neocrm-cli`，命令软链到 `/usr/local/bin`（默认在 PATH）。本发布未 notarize/staple，不能保证所有 Gatekeeper 策略放行。 |
| 一键脚本（zip） | macOS / Linux | 解压后运行 `install.sh`（或 Finder 双击 `install.command`）；自动装到 `~/.neocrm-cli/app` 并写入 PATH。卸载：`uninstall.sh` |
| `.exe` 应用安装向导（推荐） | Windows 10/11 x64 | 双击 `neocrm-cli-<ver>-win32-x64-setup.exe`；按向导安装，无需管理员权限，自动写用户 PATH，可从 Windows“已安装的应用”卸载 |
| 一键脚本（zip，备用） | Windows x64 | 解压 `neocrm-cli-win32-x64.zip` 后运行 `install.bat`（走 PowerShell `install.ps1`） |

安装后提供正式命令 `neo`。**开新终端**执行 `neo -v` 返回版本号即成功。

> 安装包为离线自包含（已内置依赖，安装无需联网）；按平台分发，请下载与你系统匹配的包。
> `neo` 是唯一正式 CLI 命令，不提供 `ncli` 兼容别名。
> 从源码构建 / 本地调试见 [开发](#开发)。

调试环境变量：`NC_DEBUG=1` 打印完整错误堆栈。

---

## 核心概念

- **项目**：以 `neo-project.json` 为根标志，`src/` 下按类型存放元数据源文件。
- **单租户**：一个项目绑定一个租户。登录凭证**不落在项目目录**，而是存到全局隐藏区 `~/.neocrm-cli/auth/<projectId>.json`（权限 0600），项目里看不到任何 token 文件。
- **source format**：
  ```
  src/
  ├── objects/<obj>__c/
  │   ├── <obj>__c.object.json          # 对象定义
  │   ├── fields/<field>__c.field.json  # 字段定义
  │   └── layouts/<layoutLabel>.form.json # 从租户拉取的表单布局元数据
  ├── global-pick-options/<label>(<apiKey>).global-pick.json # 通用选项集定义
  ├── uicomponents/<name>__c/           # UI 组件（纯源码）
  ├── nex/<v1.0|v2.0>/                   # NEX 页面扩展源码（按版本分目录）
  │   └── <obj>__c.<pageType>.<web|mobile>.nex.js
  └── codePackages/<代码包简称>/         # 后端 Java 代码包
      ├── package.json                   # neo 本地清单（非 npm）
      ├── scriptTrigger.xml              # 扩展点注册
      └── other/<company>/<module>/…     # Java 源码
  ```

---

## 快速上手

```bash
# 1. 建项目
neo init -n my-project
cd my-project

# 2. 授权租户（凭证存全局区，不入项目）
neo login -e sandbox

# 2.5 探索租户实体模型（只读，可选）
neo list object --custom                       # 有哪些自定义实体
neo describe object --api-key account --md     # 客户实体的字段字典

# 3. 生成本地源（不访问租户，apiKey 可省略 __c，自动补齐）
neo generate object --api-key project --label 项目
neo generate field  --object project --api-key amount --label 金额 --type currency

# 4. 部署到租户（本地 → 租户）
neo deploy object --api-key project__c --dry-run   # 先预演
neo deploy object --api-key project__c --confirm   # 审查后实际部署

# 5. 反向检索（租户 → 本地）
neo retrieve object --api-key project__c
```

---

## 命令总览

| 分组 | 命令 | 作用 | 访问租户 |
|---|---|---|:---:|
| 项目 | `init` | 创建本地项目骨架与 CodeBuddy `.mcp.json` | 否 |
| 授权 | `login` / `logout` / `loginstatus` | 单租户 OAuth2 授权与状态 | 是 |
| 生成 | `generate object` / `field` / `busitype` / `globalpick` / `uicomponent` / `nex` / `codepackage` | 本地生成源文件 | 否 |
| 部署 | `deploy object` / `field` / `busitype` / `globalpick` / `uicomponent` / `approvalprocess` / `source-dir` / `nex` / `codepackage` | 本地 → 租户 | 是 |
| 检索 | `retrieve object` / `busitype` / `layout` / `globalpick` / `uicomponent` / `nex` / `codepackage` | 租户 → 本地 | 是 |
| 列表 | `list nex` / `object` / `busitype` / `globalpick` / `layout` / `uicomponent` / `codepackage` | 列出租户上的元数据 | 是 |
| 查询 | `query --sql <xoql>` | 执行一次受控、只读的 XOQL 数据查询 | 是 |
| 描述 | `describe object` | 查询实体字段模型（只读，可输出 md） | 是 |
| 启用 | `enable nex` | 发布（启用）NEX 版本 | 是 |
| 禁用 | `disable nex` | 下线（禁用）NEX 版本 | 是 |

> `deploy nex` 只上传草稿、不发布；发布/下线用 `enable`/`disable nex`（见 NEX 章节）。

全局选项：`-v, --version` 显示版本号；`-h, --help` 显示帮助（每个子命令均可 `--help`）。

---

## 命令详解与参数说明

### neo init

创建本地 neocrm 项目骨架（纯本地，不访问租户或 Skills 来源）。

```bash
neo init -n my-project              # 在 ./my-project 下创建
neo init -n my-project -d .         # 在指定目录创建
```

| 参数 | 必填 | 说明 |
|---|:---:|---|
| `-n, --name <name>` | 是 | 项目名称 |
| `-d, --dir <dir>` | 否 | 目标目录，默认在当前目录下新建同名文件夹 |

行为：生成 `neo-project.json`（含自动分配的 `projectId`）、`.gitignore`、`src/` 与四个元数据根目录 `objects/`、`global-pick-options/`、`uicomponents/`、`codePackages/`，以及 CodeBuddy 项目级 MCP 配置 `.mcp.json`。配置注册随 CLI 分发的 `neocrm-platform` 代理，并以当前 Node.js 与 `bin/platform-mcp.js` 的绝对路径启动；它通过 `NEOCRM_PROJECT_ROOT` 取得当前项目登录态，项目中不保存凭证。`production` 与 `sandbox` 自动路由至正式平台 MCP，`custom` 自动路由至开发平台 MCP。已有 `.mcp.json` 时不覆盖。创建或拉取对象时，会在其目录中预建 `fields/`、`businessTypes/`、`layouts/`、`validationRules/`、`duplicateRules/`、`approvalprocesses/`、`nex/`；NEX 版本目录和其他具名文件仍按需创建。若目标位置已处于某个 neocrm 项目内，会阻止嵌套创建。

**项目初始化**：`init` 不会创建、下载或安装 `skills/`。

`.mcp.json` 是 CodeBuddy 的项目级配置，打开项目后由 CodeBuddy 读取并在首次连接时请求用户批准。Kiro、Cursor 或其他 Agent 的配置目录各不相同，不由 `neo init` 自动写入。请让用户引导相应 Agent 将 `mcpServers.neocrm-platform` 合并到其原生 MCP 配置，保留已有 MCP 服务。

---

### neo login / logout / loginstatus

单租户 OAuth2 授权。凭证存全局区 `~/.neocrm-cli/auth/<projectId>.json`，自动刷新。

```bash
neo login -e production                                      # 生产
neo login -e sandbox                                         # 沙盒
neo login -e custom -i crm                                  # https://crm.xiaoshouyi.com
neo login -e custom -i crm-cd                               # https://crm-cd.xiaoshouyi.com
neo login -e custom -i https://xxx.xiaoshouyi.com           # 也支持完整实例地址
neo logout
neo loginstatus
```

`login` 参数：

| 参数 | 必填 | 说明 |
|---|:---:|---|
| `-e, --env <env>` | 是 | 登录环境：`production` / `sandbox` / `custom` |
| `-i, --instance-url <url>` | custom 必填 | CRM 实例地址；支持三级域名简写（如 `crm` → `https://crm.xiaoshouyi.com`、`crm-cd` → `https://crm-cd.xiaoshouyi.com`），也支持完整 URL |
| `--login-url <url>` | 否 | custom 可选：显式指定登录域名（默认由实例地址把 `crm` 前缀替换为 `login` 推导） |

预置环境地址：
- `production` → 实例 `https://crm.xiaoshouyi.com`，登录 `https://login.xiaoshouyi.com`
- `sandbox` → 实例 `https://crm-sandbox.xiaoshouyi.com`，登录 `https://login-sandbox.xiaoshouyi.com`

`logout`：清除当前项目的登录凭证（无参数）。
`loginstatus`：显示租户 / 环境 / 用户 / token 有效期（无参数）。

登录成功后，CLI 会输出以下可直接发送给 Agent 的下一步提示词：

```text
a. “帮我拉取当前租户的对象以及字段定义”
b. “帮我拉取租户中的后端代码”
c. “帮我拉取租户中的 NEX 代码”
d. “帮我拉取租户中的自定义组件”
e. 或者直接说出您想做的事情
```

`neo init` 完成时也会在命令输出中明确要求 Agent 主动推荐登录，并先让用户选择 `sandbox` / `production` / `custom`，不会默认登录生产环境。

---

### neo generate

在本地生成元数据源文件，**不访问租户**。

#### generate object

对象能力开关使用平台默认值：业务类型、校验规则、查重规则、脚本执行器默认开启；操作日志、团队成员、系统动态流默认关闭。可显式覆盖任一开关。

```bash
neo generate object --api-key project --label 项目 \
  --auto-number "PA{YYYY}{MM}{DD}{000}" --auto-number-start 1 \
  --enable-history-log true --enable-dynamic-feed true \
  --description 项目对象
```

| 参数 | 必填 | 说明 |
|---|:---:|---|
| `--api-key <apiKey>` | 是 | 对象 apiKey，可省略 `__c`，自动补齐 |
| `--label <label>` | 是 | 对象显示名称 |
| `--description <desc>` | 否 | 对象描述，默认取 label |
| `--icon-id <id>` | 否 | 图标 ID；省略则使用系统默认图标 |
| `--auto-number <format>` | 否 | 主字段用自动编号并指定格式，如 `"PA{YYYY}{MM}{DD}{000}"`；省略 `--auto-number-start` 时起始编号默认 `1`，且与 `--name-item` 互斥 |
| `--auto-number-start <number>` | 否 | 自动编号起始编号，默认 `1`；仅与 `--auto-number` 一起使用 |
| `--name-item <json>` | 否 | 完整主字段 JSON；自动编号必须包含 `itemType:9`、`dataFormat`；`startNumber` 省略时默认 `1`，如 `'{"itemType":9,"dataFormat":"PA{000}","startNumber":1}'`；与 `--auto-number` 互斥 |
| `--enable-history-log <true\|false>` | 否 | 是否启用操作日志，默认 false |
| `--enable-busitype <true\|false>` | 否 | 是否启用业务类型，默认 true |
| `--enable-checkrule <true\|false>` | 否 | 是否启用校验规则，默认 true |
| `--enable-duplicaterule <true\|false>` | 否 | 是否启用查重规则，默认 true |
| `--enable-script-executor <true\|false>` | 否 | 是否启用脚本执行器，默认 true |
| `--enable-group-member <true\|false>` | 否 | 是否启用团队成员，默认 false |
| `--enable-dynamic-feed <true\|false>` | 否 | 是否启用系统动态流，默认 false |

> 自动编号主字段省略 `startNumber` 时 CLI 会写入 `1`。字段级自动编号创建接口支持 `dataFormat` 与 `rebuildAutoNumber`。

#### generate field

```bash
neo generate field --object project --api-key amount --label 金额 \
  --type currency --description 合同金额
```

| 参数 | 必填 | 说明 |
|---|:---:|---|
| `--object <objApiKey>` | 是 | 所属对象 apiKey（可省略 `__c`） |
| `--api-key <apiKey>` | 是 | 字段 apiKey，可省略 `__c`，自动补齐 |
| `--label <label>` | 是 | 字段显示名称 |
| `--type <type>` | 是 | 字段类型（友好名，见[字段类型](#字段类型)） |
| `--description <desc>` | 否 | 字段描述，默认取 label |
| `--max-length <n>` | 否 | 最大长度。不传则使用类型默认最大长度（text=255, textarea/richText=65535, image/file=9）；实数/货币类型默认 **13**，百分比按 `15 - decimal` 计算（另受 ≤10 限制） |
| `--decimal <n>` | 否 | 小数位。实数类型（decimal/currency/percent）不传默认 **2**。校验：maxLength + decimal ≤ 15 |
| `--data-format <format>` | autoNumber 时必填 | 自动编号格式，例如 `ORD-{0000}` |
| `--auto-number-start <number>` | 否 | 自动编号起始编号，默认 `1`；仅 autoNumber 可用 |
| `--rebuild-auto-number <true\|false>` | 否 | 创建自动编号字段时是否为已有记录计算编号，默认 `false`；仅 autoNumber 可用 |

为已存在实体新增自动编号字段时，可先生成 source 并按需预演。`--rebuild-auto-number false` 保持已有记录不回填编号；设为 `true` 会请求平台为已有记录计算编号。

```bash
neo generate field --object order__c --api-key orderNo --label "Order Number" \
  --type autoNumber --data-format "ORD-{0000}" --auto-number-start 1 --rebuild-auto-number false
neo deploy field --object order__c --api-key orderNo__c --dry-run
neo deploy field --object order__c --api-key orderNo__c
```

生成的字段创建请求包含：

```json
{
  "apiKey": "orderNo",
  "label": "Order Number",
  "itemType": 9,
  "dataFormat": "ORD-{0000}",
  "startNumber": 1,
  "rebuildAutoNumber": false
}
```

> 若类型需要额外参数（如 `singleSelect` 的 `pickOption`、`reference` 的 `referObjectApiKey/cascadeDelete/linkLabel`），`generate` 会在源文件写入 `__requiredParams` 提示（已自动补齐的 maxLength/decimal 不再出现在提示中），编辑源文件补全后再 `deploy`。

#### generate uicomponent

```bash
neo generate uicomponent --name bidList --label 标书列表
```

| 参数 | 必填 | 说明 |
|---|:---:|---|
| `--name <name>` | 是 | 组件名（小写开头，可省略 `__c`，自动补齐） |
| `--label <label>` | 否 | 组件显示名称 |

生成纯源码骨架（`index.tsx` / `model.ts` / `types.ts` / `style.scss` / `doc.md`），构建产物在 deploy 时才生成。

---

### neo deploy

把本地源部署到租户。**必须指定目标，无全量部署命令。**

```bash
neo deploy object      --api-key project__c [--dry-run] [--partial] [--confirm] # 对象 + 其所有字段
neo deploy field       --object project__c --api-key amount__c [--dry-run]
neo deploy uicomponent --name bidList__c [--dry-run]
neo deploy approvalprocess <approval-flow-spec.json> --confirm # 自动 check 后创建设计态流程
neo deploy source-dir  src/objects/project__c [--dry-run]         # 按路径部署对象目录
```

各子命令参数：

| 子命令 | 参数 | 必填 | 说明 |
|---|---|:---:|---|
| `object` | `--api-key <apiKey>` | 是 | 对象 apiKey；对象成功后预检字段依赖，按稳定分层顺序逐个部署 `fields/` 下字段 |
| `object` | `--dry-run` | 否 | 可选预演，只显示 create/update 判定，不写入 |
| `object` | `--partial` | 否 | 显式允许字段预检失败时，继续部署对象和其他通过预检的字段；省略时任一预检失败均不写入 |
| `object` | `--confirm` | 非预演时必填 | 明确确认写入租户元数据 |
| `field` | `--object <objApiKey>` | 是 | 所属对象 apiKey |
| `field` | `--api-key <apiKey>` | 是 | 字段 apiKey；写入前校验字段参数、关联对象和 lookup 依赖 |
| `field` | `--dry-run` | 否 | 可选预演；省略时直接写入租户 |
| `uicomponent` | `--name <name>` | 是 | 组件名；自研 esbuild 构建后 multipart 上传 |
| `uicomponent` | `--dry-run` | 否 | 预演 |
| `approvalprocess` | `<source-file>`（位置参数） | 是 | 根对象为 `ApprovalFlowSpec/1.1`，或含 `spec` 属性的技能包编译结果；只创建新的设计态流程 |
| `approvalprocess` | `--confirm` | 是 | 明确确认写入；命令会在创建前自动调用审批流 `check`，预检失败则拒绝写入 |
| `source-dir` | `<dir>`（位置参数） | 是 | 源目录路径，当前支持含 `*.object.json` 的对象目录 |
| `source-dir` | `--dry-run` | 否 | 预演 |

`deploy approvalprocess` 仅支持经确认的单流程基础创建：它会先调用流程 `check`，然后创建新的 `DESIGNING` 流程；不提供 `--dry-run`、Patch、创建版本、启用、禁用、跨会话确认或效果未知恢复。命令返回后应从结果获取定义 ID，使用 `neo retrieve approvalprocess --definition-id <id>` 回读并用技能包解读器核对实际配置。

---

### neo retrieve

从租户检索元数据到本地。标准与自定义对象均写入 `src/objects`；标准对象仅支持检索，不可 deploy。

```bash
neo retrieve object      --api-key project__c    # 自定义对象、字段和业务类型，写入 label(apiKey) 目录
neo retrieve object      --api-key account       # 标准对象、字段和业务类型，以相同目录结构写入本地
neo retrieve layout      --entity project__c     # 该自定义实体的表单、列表和详情布局
neo retrieve layout      --entity project__c --type list # 仅列表布局
neo retrieve layout      --entity project__c --json # 机器可读结果
neo retrieve approvalprocess --definition-id 123 # 单条审批流快照
neo retrieve approvalprocess --entity project__c # 分页拉取对象下全部流程并写入索引
neo retrieve uicomponent --name bidList__c
```

| 子命令 | 参数 | 必填 | 说明 |
|---|---|:---:|---|
| `object` | `--api-key <apiKey>` | 是 | 标准与自定义对象均检索对象、字段及业务类型到 `src/objects/<label>(<apiKey>)/`，业务类型写入 `businessTypes/`。标准对象使用 `<apiKey>.object.json` 和 `fields/`，但对象 JSON 含 `"custom": false` 标记，任何 deploy 入口都会拒绝部署。 |
| `layout` | `--entity <apiKey>` | 是 | 自定义实体 API Key；默认只读拉取该实体的表单、列表和详情布局到 `src/objects/<label>(<apiKey>)/layouts/` |
| `layout` | `--type <form\|list\|detail\|all>` | 否 | 布局类型，默认 `all` |
| `approvalprocess` | `--definition-id <id>` 或 `--entity <apiKey>` | 二选一 | 单条导出或分页导出对象下全部审批流；快照和 `index.json` 写入关联对象的 `approvalprocesses/` 子目录，文件名为 `<流程名称>(<definitionId>).approvalprocess.snapshot.json` |
| `layout` | `--json` | 否 | 输出机器可读的 entityApiKey、outputDir、layoutCount、writtenFiles、failedLayouts、warnings |
| `uicomponent` | `--name <name>` | 是 | 组件名；纯 REST 下载 codeLib zip 解压回写源码 |

`retrieve layout` 只调用三类布局的列表和详情 GET 接口，不会创建、更新或删除远端布局。默认拉取表单、列表和详情布局；可通过 `--type form|list|detail|all` 筛选。文件名为 `<安全化布局标签>.<type>.json`，例如 `默认布局.form.json`、`默认列表.list.json`；同类型中同名（或清洗后同名）布局才追加远端唯一标识的确定性后缀以避免覆盖。重复执行会覆盖同一布局文件。实体存在但某类布局为空时命令继续处理其余类型并给出提示。

> `retrieve nex` / `retrieve codepackage` 见对应章节。

---

### neo list

列出租户上的元数据。

```bash
neo list object [--custom|--standard]  # 列出实体（默认标准+自定义）
neo list layout --entity project__c    # 列出该实体三类布局
neo list layout --entity project__c --type form --json
neo list uicomponent                   # 列出自定义 UI 组件
neo list nex [--client-type web]       # 列出 NEX 代码（见 NEX 章节）
neo list codepackage                   # 分页列出租户全部 type=0 代码包（见代码包章节）
```

#### list object

列出租户上的实体（apiKey / label），默认同时列标准与自定义并分组展示。

| 选项 | 说明 |
|---|---|
| `--custom` | 只列自定义实体 |
| `--standard` | 只列标准实体 |

#### list uicomponent

无参数。列出租户上所有自定义 UI 组件（cmpType / label）。

#### list layout

只读列出一个自定义实体的布局摘要，不写入本地文件：

```bash
neo list layout --entity customEntity9__c                  # 表单、列表、详情三类布局
neo list layout --entity customEntity9__c --type form      # 仅表单布局
neo list layout --entity customEntity9__c --type list      # 仅列表布局
neo list layout --entity customEntity9__c --type detail    # 仅详情布局
neo list layout --entity customEntity9__c --json           # 机器可读输出
```

| 选项 | 说明 |
|---|---|
| `--entity <apiKey>` | 必填；以 `__c` 结尾的自定义实体 API Key |
| `--type <form\|list\|detail\|all>` | 可选，默认 `all`；分别对应表单布局、列表布局、详情布局 |
| `--json` | 输出 `entityApiKey`、布局类型、布局列表、失败类型和警告等机器可读结果 |

命令仅发起三个布局类型各自的 GET 查询。若某一种类型查询失败，仍会返回其余成功类型的结果，并以非零退出码标记该次查询不完整。

> `list nex` 和 `list codepackage` 见对应章节。

---

### neo query

在当前 neo 项目已登录的租户中执行**一次只读 XOQL SELECT**。命令会先核对根实体的字段目录，不写入本地 source 或租户数据。

```bash
neo query --sql "SELECT id, name FROM project__c WHERE id > 0 ORDER BY id LIMIT 50"
neo query --sql "SELECT COUNT(id) totalCount FROM project__c WHERE status__c = 1" --json
```

| 选项 | 必填 | 说明 |
|---|:---:|---|
| `--sql <xoql>` | 是 | 受限 XOQL SELECT。必须是单实体、显式字段且带 WHERE；未写 LIMIT 时默认 50，最大 300。 |
| `--json` | 否 | 输出机器可读结果，包括本页记录、`returnedCount`、服务端 `totalSize`/`count` 和完整性状态。 |
| `--include-sensitive` | 否 | 只有在确有必要且已获用户明确确认时，才允许查询加密、富文本、图片或文件字段。 |

命令拒绝写操作、多语句、JOIN、`SELECT *`、无 WHERE、`WHERE 1=1` 以及超过 300 行的 LIMIT；不会自动翻页、导出 CSV 或写文件。查询接口的 `totalSize` 和 `count` 都表示本次查询返回记录数，不能视为总匹配数。需要总数时，使用完全相同 WHERE 条件单独执行 `SELECT COUNT(id)`，并读取其结果列。

完整 XOQL 语法、字段类型限制、关联和分页规则见 [neo-xoql-query](skills/neo-xoql-query/SKILL.md) 技能。执行前仍须先按该技能的流程用 `neo list object` 和 `neo describe object` 核对实体、关联、筛选字段及选项编码。

---

### 通用选项集

通用选项集由 [neo-global-pick-management](skills/neo-global-pick-management/SKILL.md) 技能定义完整工作流。先用 `neo list globalpick --with-option` 发现可复用项；新建或拉取时，source 文件使用 `src/global-pick-options/<label>(<apiKey>).global-pick.json`，显示名称便于识别、括号内 apiKey 保持稳定身份。CLI 仍可读取旧版 `<apiKey>.global-pick.json`，并在 retrieve 时按远端当前 label 安全迁移，避免重复 source。编辑 source 后执行 `neo deploy globalpick --api-key <apiKey> --dry-run`。只有用户确认目标租户和变更范围后，才执行 `--confirm`，随后以 `neo list globalpick --api-key <apiKey> --with-option --json` 回读。

MCP 当前没有通用选项集管理工具。实体字段引用通用选项集时使用 `neo generate field --type singleSelect|multiSelect --global-pick-item-api-key <apiKey>`；字段 source 的 `referGlobal: true` 与 `globalPickItemApiKey` 必须和 `pickOption` 互斥，且部署前会验证远端选项集存在且唯一。

### 校验规则与查重规则

规则按实体保存为可评审的 source-driven JSON；CLI 和 MCP 复用相同元数据实现与 `neo login` 凭证。规则同步会覆盖相同 apiKey 的本地快照，CLI 部署会逐项按 apiKey 进行 upsert；部署前应审核 `git diff` 并取得目标租户的明确确认。

```bash
# 只读发现，不写本地 source
neo list validationrule --entity project__c
neo list duplicaterule  --entity project__c

# 从租户同步完整规则 JSON 到本地
neo retrieve validationrule --entity project__c
neo retrieve duplicaterule  --entity project__c

# 本地 source -> 租户
neo deploy validationrule --entity project__c
neo deploy duplicaterule  --entity project__c

# 仅切换租户侧规则状态，不改写本地 source
neo enable validationrule --entity project__c --api-key amountPositive__c
neo disable validationrule --entity project__c --api-key amountPositive__c
neo enable duplicaterule --entity project__c --api-key serialUnique__c
neo disable duplicaterule --entity project__c --api-key serialUnique__c
```

本地目录：

```text
src/objects/<label>(<objectApiKey>)/validationRules/<规则label>.validation.json
src/objects/<label>(<objectApiKey>)/duplicateRules/<规则label>.duplication.json
```

MCP 只提供发现与同步：`list_validation_rules`、`list_duplicate_rules`（只读）；`retrieve_validation_rules`、`retrieve_duplicate_rules`（写本地 source）。规则部署仅能通过 CLI 执行，不经 MCP 暴露。

校验规则的 `errorConditionFormula` 为 true 时阻止保存；查重规则部署前必须人工核对参与字段、匹配模式和重复处理策略。`list` 只能确认元数据已返回，仍需用真实数据操作验证规则运行时效果。

### neo describe

查询租户元数据（只读），不写本地源文件。查询逻辑与后续 MCP 工具共用同一套核心。

```bash
neo describe object --api-key account                        # 结构化摘要（字段/类型/Java类型/关联/选项数）
neo describe object --api-key account --md                   # 输出可读字段字典（Markdown，按类型分组）
neo describe object --api-key account --md --relationships   # 附正向关联关系视图
neo describe object --api-key account --md -o docs/account.md # 写入文件而非打印
```

#### describe object

| 选项 | 必填 | 说明 |
|---|:---:|---|
| `--api-key <apiKey>` | 是 | 实体 apiKey |
| `--md` | 否 | 输出可读字段字典（按 基础/单选/多选/关联/关联查询/级联/计算聚合/文件图片 分组，含选项值、关联目标、Java 类型） |
| `--relationships` | 否 | 附带正向关联关系（reference/detail/多值/多态） |
| `-o, --out <file>` | 否 | 将结果写入文件而非打印到终端 |

默认（不带 `--md`）输出精简的结构化字段清单，自定义字段以 `*` 标注。字段类型按 `itemType` 映射为友好中文名与 `getAttribute()` 的 Java 类型（供后端开发参考）。

---

## NEX 页面扩展

CLI 管理 **NEX 1.0 与 NEX 2.0** 标准页面扩展代码（对标准页面的表单/列表/详情/首页覆盖属性、挂事件的 `view(ctx, props)` 代码）。NEX 代码**不需要编译**。

- **版本背景**：
  - **RPA/breeze**（经典版表单，需编译）— 不在 CLI 范围
  - **NEX 1.0** — 开通 NeoUI 但未升级 Neo2.0 表单的对象（`--nex-version v1.0`）
  - **NEX 2.0** — 已升级 Neo2.0 表单（或框架兼容）的对象（`--nex-version v2.0`，默认）
- **源码布局**：对象页的 `generate nex` 与 `retrieve nex` 均写入 `src/objects/<label>(<objectApiKey>)/nex/<v1.0|v2.0>/<pageType>.<web|mobile>.nex.js`；`deploy nex` 优先读取该路径，并兼容历史 `src/nex/` 文件。
- **codeName（含终端）**：`<objectApiKey>.<pageType>.<web|mobile>.nex`，如 `customEntity1__c.form.web.nex`。省略终端 `<objectApiKey>.<pageType>.nex` 表示两端。
- **终端标签**：`web`=网页端、`mobile`=移动端（内部映射平台 clientType：mobile↔h5）。
- **接口**：`/rest/metadata/v3.1/nex/codes`，请求头带 `Authorization` + `xsy-tenant-id` + `xsy-user-id`（复用 `neo login` 凭证）。`--nex-version` 的 `v1.0/v2.0` 会自动映射为接口路径参数 `v1/v2`。

```bash
neo list     nex [--client-type web|mobile]                          # 列 NEX 代码（自动合并 v1/v2）
neo generate nex --page form --object account [--terminal web] [--nex-version v2.0]
neo retrieve nex -n customEntity1__c.form.web.nex [--nex-version v2.0] [--code-version 3]
neo retrieve nex --object customEntity1__c [--nex-version v1.0|v2.0] # 拉取该对象全部 NEX
neo deploy   nex customEntity1__c.form.web.nex [--dry-run]           # 仅上传草稿，不发布
neo enable   nex customEntity1__c.form.web.nex [--code-version 3]    # 发布（启用）
neo disable  nex customEntity1__c.form.web.nex                       # 下线（禁用）
```

> **上传与发布分离**：工具内无法预览效果，`deploy nex` 只把源码**上传为开发态草稿**，不发布。在页面设计器预览确认后，用 `neo enable nex` 发布（或直接在预览界面发布）；需下线用 `neo disable nex`。`enable`/`disable` 从租户侧操作、不依赖本地文件，默认作用于最新（开发态/已发布）版本，可用 `--code-version` 指定。

### list nex

| 参数 | 必填 | 说明 |
|---|:---:|---|
| `--client-type <type>` | 否 | 过滤终端：`web` / `mobile`；不传则返回全部 |

> `list nex` 会自动合并 v1/v2 两组输出，**不接受** `--nex-version`（版本体现在每行输出的 `[版本]` 标注里）。

### generate nex

按 **页面类型 + 实体** 生成 `view(ctx,props)` 最小骨架。

| 参数 | 必填 | 说明 |
|---|:---:|---|
| `--page <pageType>` | 是 | 页面类型：`form` / `list` / `detail` / `home` |
| `--object <objectApiKey>` | form/list/detail 必填 | 实体 API 名称；`home` 首页不关联实体，无需此参数 |
| `--terminal <t>` | 否 | 终端：`web`（默认）/ `mobile` |
| `--nex-version <v>` | 否 | `v1.0` / `v2.0`（默认 `v2.0`） |

> 目标文件已存在则报错，不覆盖。

### retrieve nex

拉取开发态源码到本地。`--name` 与 `--object` 必须二选一。

| 参数 | 必填 | 说明 |
|---|:---:|---|
| `-n, --name <codeName>` | 与 `--object` 二选一 | 含或不含终端；不带终端则 **web + mobile 两端都拉**（某端无代码只提示不中断） |
| `--object <objectApiKey>` | 与 `--name` 二选一 | 拉取指定对象下全部 NEX 页面、终端与版本 |
| `--nex-version <v>` | 否 | `v1.0` / `v2.0`（单段拉取默认 `v2.0`；批量拉取按版本过滤） |
| `--code-version <n>` | 否 | 仅单段拉取可用；指定版本，默认取最新 |

### deploy nex（仅上传草稿）

`deploy nex` **只把本地源码上传为开发态草稿，不发布**；发布须经预览确认后用 `enable nex`。`<codeName>` 为位置参数。

| 参数 | 必填 | 说明 |
|---|:---:|---|
| `<codeName>` | 是 | 含终端只上传该端；不带终端则上传本地已存在的所有端 |
| `--nex-version <v>` | 否 | `v1.0` / `v2.0`（默认 `v2.0`） |
| `--code-version <n>` | 否 | 指定版本；否则最新未发布则覆盖草稿，已发布则 +1 新建 |
| `--dry-run` | 否 | 预演，只打印将上传的 codeName/版本/端，不写入 |

- NEX 2.0 源码禁用 `async/await`（用 `Promise.then()`），上传前会拦截（去注释后检测）。
- 上传带 `codeFingerprint = md5(源码)`。

### enable nex / disable nex（发布 / 下线）

`enable nex` 发布已上传版本，使其线上生效——从租户拉取开发态源码构建 `compiledCode = (function(){ <源码>; return view; })` 后 publish（已实测生效），**不依赖本地文件**，默认发布最新开发态版本。`disable nex` 把已发布版本下线，默认作用于最新已发布版本。二者含终端只作用该端、不带终端作用两端；均支持 `--code-version` / `--nex-version` / `--dry-run`。

其它：
- 该接口主要在测试/灰度环境提供；未部署的环境返回 `1010003 资源不存在`。
- `copy`/`delete`/`preview` 等接口已知但 CLI 未开放命令（保守：不做删除）。

---

## 后端代码包 codepackage

管理 NeoCRM PaaS 平台的**业务逻辑 Java 代码**（Trigger、自定义 API、计划作业、流程扩展、工具类）。生成、部署和下载以本地目录为「真源」，租户列表则直接使用远端全量接口；统一复用 `neo login` 凭证。`codepackage` 可简写为 `cpkg`。

```bash
neo list     codepackage                                               # 发现租户全部 type=0 代码包
neo retrieve codepackage --package other.xsy.account [--name 客户管理] # 按完整 Java 包名下载
neo generate codepackage --name 客户管理 --package other.xsy.account    # 生成骨架（纯本地）
neo deploy   codepackage --name 客户管理 [--dry-run]                    # 打包上传 + 安装
```

### 源码布局

```
src/codePackages/<代码包简称>/
├── package.json          # neo 维护的本地清单：{ displayName, javaPackage, company, module, description }（非 npm，不进上传 zip）
├── scriptTrigger.xml     # 扩展点注册（一个代码包只有一个 <config> 节点）
├── doc.md
└── other/<company>/<module>/
    ├── triggers/   *.java
    ├── apis/       *.java
    ├── schedules/  *.java
    ├── flows/      *.java     # 审批/工作流/自动流/可视化流事件
    └── utils/      *.java
```

> **Java 包名**以 `other` 开头，部署时必须是三级（如 `other.xsy.account`），全部小写。

### generate codepackage

| 参数 | 必填 | 说明 |
|---|:---:|---|
| `--name <displayName>` | 是 | 代码包简称（本地目录名） |
| `--package <javaPackage>` | 是 | Java 包名（三级，如 `other.xsy.account`） |
| `--company <company>` | 否 | 公司标识，默认取 Java 包名第二级 |
| `--module <module>` | 否 | 模块标识，默认取 Java 包名第三级 |
| `--description <desc>` | 否 | 代码包描述 |

纯本地生成骨架（目录 + 空 `scriptTrigger.xml` + `doc.md` + 本地清单），不访问租户。

### deploy codepackage

| 参数 | 必填 | 说明 |
|---|:---:|---|
| `--name <displayName>` | 是 | 代码包简称（本地目录名） |
| `--dry-run` | 否 | 预演，只判定 will-create/will-update，不发写请求 |

流程：打包 zip → 建包（租户上不存在时）→ 上传源码 → 安装（一步生效）。

### retrieve codepackage

| 参数 | 必填 | 说明 |
|---|:---:|---|
| `--package <javaPackage>` | 是 | Java 包名（三级，如 `other.xsy.account`） |
| `--name <displayName>` | 否 | 本地目录名；省略时取业务逻辑代码的标签名称，标签缺失时回退为 Java 包名最后一段 |

按完整 Java 包名从租户下载代码包 zip，解压写入新目录并补齐清单。未指定 `--name` 时，目录名使用租户业务逻辑代码的标签名称；若标签为空则回退为 Java 包名最后一段。若目标文件、目录或符号链接已存在，命令会失败且不会覆盖用户内容。

### list codepackage

无参数。调用 `GET /rest/metadata/v2.0/dx/logic/packages/?pageNo=<n>&pageSize=1000&type=0`，从第 1 页连续读取当前租户全部 `type=0` 业务逻辑代码包；该过程不扫描本地 manifest 或 `src/codePackages`。

分页数组是 `data.records.codePackageList`，远端原始总数是 `data.records.counts`；`data.totalSize` 和 `data.count` 不是代码包总数。实现结合 counts、累计原始记录数和短页有限终止，检测 counts 变化、低报及重复页，并按稳定 `id`、缺少 id 时按 `packageTitle` 去重。

列表中的 `codePackageName` 映射为展示名 `displayName`，`packageTitle` 映射为完整 Java 包名 `javaPackage`。典型流程：

```bash
neo list codepackage
neo retrieve codepackage --package <列表返回的 javaPackage>
```

列表仅输出 `id`、`displayName`、`javaPackage`、`version`、`type`、`classCount`、`instanceVersion`、`reloadFlag`、`deleted` 白名单字段。单包查询 `/scripts/packages?packageName=<javaPackage>` 仍用于 deploy/retrieve；deploy 始终是上传并安装。当前不提供 delete/uninstall 能力。

### 平台 API

| 操作 | 接口 |
|---|---|
| 租户全量列表 | `GET /rest/metadata/v2.0/dx/logic/packages/?pageNo=<n>&pageSize=1000&type=0` |
| 单包查询 | `GET /rest/metadata/v2.0/scripts/packages?packageName=<javaPackage>` |
| 建包 | `POST /rest/metadata/v2.0/scripts/packages` |
| 上传 | `POST /rest/metadata/v2.0/scripts/packages/files?packageName=<pkg>` |
| 安装 | `POST /rest/metadata/v2.0/scripts/packages/installations` |

> 平台侧编译 Java，neo 只负责打包上传，本地无需 JDK 编译产物。

---

## 匿名使用统计（telemetry）

CLI/MCP/Skills 的使用统计默认启用，用于按租户观察每日调用情况。未配置或缺少 `settings.json` 中的 `telemetry.enabled` 时按启用处理；执行 `neo telemetry disable` 会明确写入关闭状态并清除本地待上报事件，之后不会因为默认策略重新打开，执行 `neo telemetry enable` 可恢复。`neo telemetry status` 查看状态，`neo telemetry show` 审查本地队列，`neo telemetry flush` 手动提交，`neo telemetry clear` 只清除队列。

默认接收地址为 `https://crm-gray.xiaoshouyi.com/json/global_felog/exec?v=1`，production、sandbox、custom 所有环境均发送到该灰度地址，不按环境切换。可用 `NEO_TELEMETRY_ENDPOINT` 或 `neo telemetry enable --endpoint <https-url>` 覆盖地址。

上报的每条 `task_summary` 包含 CLI/MCP/Skills 分类、成功/失败结果、耗时、登录实例标识、数字租户 ID、数字用户 ID、当前 CLI 版本、匿名安装标识，以及 Skills 来源/数量等白名单统计；最终 `otherInfo` 可选包含稳定的 `operation` 字段和已识别的 AI 客户端 `userAgent`。登录实例仅取 URL 的首级域名标签，例如 `https://crm-gray.xiaoshouyi.com` 写为 `crm-gray`，不上传完整 URL。`userAgent` 仅在识别出 Kiro、Cursor、Claude、CodeBuddy 或 WorkBuddy 时写入。它只会是代码白名单中的分类，例如 CLI `list`/`retrieve`（嵌套命令归属顶层分组）、MCP `login_status`/`get_nex` 或 Skills `sync`；未知、未允许或旧队列事件会省略该字段，不会原样上报。请求使用现有本地队列和批量 flush。缺少或非法租户/用户 ID 时跳过该事件，不使用测试 ID。不会发送原始命令或工具名称/路径、命令参数或选项值、MCP arguments/输出、SQL、对象名称、项目路径、源码、提示词、Skills registry URL/名称/内容、完整错误文本、租户名称、URL 查询参数、Authorization、OAuth token、Cookie、API key 或其他凭证。

开关优先级为：`DO_NOT_TRACK=true` 始终禁用；其次 `NEO_TELEMETRY=false` 禁用；`NEO_TELEMETRY=true` 按既有语义强制启用；没有环境变量时遵循 settings 中明确的 `telemetry.enabled`，缺失则默认启用。

---

## 内置 Skills 打包素材

Skills 仅作为离线安装包的构建素材；CLI 不提供 Skills 的列出、安装或更新命令。

### 发布流程（维护者）

发布技能树由仓库根的两层来源组成：`skills/neo-based-skills/` 是完整基线，`skills/ncli-based-skills/` 是同名 neo 工作流覆盖。所有组装脚本都先保留完整基线，再用**全部** neo 技能替换同名目录：

```bash
# 刷新随 npm/离线安装包内置的技能
bash neocrm-cli/scripts/sync-skills.sh

# 单一 zip（对应默认源）
bash neocrm-cli/scripts/build-skills-zip.sh
# 产物：neocrm-cli/dist-skills/skills.zip（技能目录在 zip 根）
# 把它覆盖上传到上面的 COS 地址即可，客户端据 ETag/Last-Modified 自动感知更新

# 或：清单目录形态（per-skill 增量）
bash neocrm-cli/scripts/build-skills-registry.sh
# 产物：neocrm-cli/dist-skills/index.json + 每技能一个 .zip，整目录上传到公开服务
```

可设置 `NEOCRM_SKILLS_OUT=/临时/输出目录` 安全检查 zip/registry 产物而不覆盖默认 `dist-skills/`。

> **提示**：把 COS 该对象的 `Cache-Control` 设短一些（或每次更新即刷新 CDN），否则条件请求可能命中边缘缓存的旧对象，导致更新不及时。CLI 请求已带 `Cache-Control: no-cache`。

### 随包内置（离线兜底）

`neocrm-cli/skills/` 是随包分发的兜底产物，由 `scripts/sync-skills.sh` 通过同一套“完整基线 + neo 同名覆盖”逻辑组装（`pack-zip.sh` 打包前会自动同步）。远端与缓存都不可用时用它。

---

## 字段类型

`--type` 支持的友好类型名（内部映射平台 itemType）：

| 友好名 | itemType | 需额外参数 | 备注 |
|---|:---:|---|---|
| `text` | 1 | maxLength | |
| `textarea` | 2 | maxLength | |
| `singleSelect` | 3 | pickOption 或 referGlobal+globalPickItemApiKey | |
| `multiSelect` | 4 | pickOption 或 referGlobal+globalPickItemApiKey | |
| `integer` | 5 | — | |
| `decimal` | 6 | maxLength, decimal | |
| `currency` | 6 | maxLength, decimal | 额外置 `currency:true` |
| `date` | 7 | — | |
| `autoNumber` | 9 | dataFormat | 可为已有实体新增字段；`startNumber` 默认 1，`rebuildAutoNumber` 默认 false |
| `reference` | 10 | referObjectApiKey, cascadeDelete, linkLabel | |
| `detail` | 10 | referObjectApiKey, cascadeDelete, linkLabel | 主子明细，额外置 `detail:true` |
| `datetime` | 21 | — | |
| `phone` | 22 | — | |
| `email` | 23 | — | |
| `url` | 24 | — | |
| `lookup` | 26 | joinLinkItemApiKey, joinItemApiKey | |
| `image` | 29 | maxLength | |
| `boolean` | 31 | — | |
| `geolocation` | 32 | — | |
| `percent` | 33 | maxLength(≤10), decimal | |
| `polyReference` | 34 | referEntityIds | |
| `time` | 38 | — | |
| `file` | 39 | maxLength | |
| `richText` | 40 | maxLength | |
| `multiValueReference` | 41 | referObjectId, cascadeDelete, linkLabel | |

需要额外参数的类型，`generate` 会在源文件写入 `__requiredParams` 提示，编辑补全后再 `deploy`。

---

## 部署行为

- **upsert**：部署前查询租户，存在则更新（PATCH），不存在则创建（POST，创建时自动去掉 `__c` 后缀，平台会自动追加）。
- **部署前字段分析**：`deploy object` 与 `deploy field` 都会在任何 Metadata API 写请求前校验字段定义。校验覆盖 select 选项来源及 `optionCode`、关联字段的目标对象/cascadeDelete/linkLabel、lookup 的本对象关联字段和目标字段、polyReference 目标对象，以及 `maxLength`/`decimal` 的统一数值规则。目标对象/字段快照在同一次部署内按 API Key 缓存，`--dry-run` 同样执行分析。
- **顺序与预检**：`deploy object` 在对象写入前读取全部自定义字段，生成稳定的拓扑分层计划：基础字段在第 1 层，`reference` / `detail` / `multiValueReference` / `polyReference` 在第 2 层，`lookup` 在第 3 层；同层按字段 apiKey 稳定排序。`lookup.joinLinkItemApiKey` 必须指向本对象已存在或本次计划中的关联字段，且计划中的关联字段会先部署。
- **关联目标与错误**：`reference`、`detail`、`multiValueReference` 和 `polyReference` 的目标对象必须能在租户对象快照中找到（当前对象自身除外）。错误输出包含代码、字段类型、依赖字段/属性、原因和修复建议；默认模式下，重复字段、缺失依赖、lookup 指向非关联字段或循环依赖都会阻止任何 Metadata API 写入。
- **部分部署**：仅 `deploy object --partial --confirm` 明确启用后，字段预检失败才会被隔离；对象和其他通过预检的字段仍可能写入租户，命令仍会以非零码报告失败项。应先运行同样带 `--partial` 的 dry-run，审查每项结果后再确认写入。
- **单字段命令**：`deploy field` 保持单字段 upsert 行为，不执行对象批量依赖编排。
- **字段更新范围**：更新时仅提交可改属性（`label` / `description` / `helpText` / `defaultValue` / `maxLength` / `decimal` / `dataFormat` / `cascadeDelete`），`itemType` 不可改。
- **dry-run**：`--dry-run` 不发起写请求；`deploy object` 会按实际计划顺序输出每个字段的层级与前置字段依赖。
- **结果汇总**：末尾输出成功/失败统计，任一失败进程以非零码退出。

> 写入 API 需要租户开启「Metadata API」功能点；沙盒默认可用，生产需申请开通。

---

## UI 组件：源码与构建分离

`uicomponents/<name>/` 下**只放源码**，用户只维护这几个文件：

```
uicomponents/bidList__c/
├── index.tsx     # React 类组件（默认导出），最外层唯一 className = 组件名（样式隔离）
├── model.ts      # export class XxxModel，对接页面设计器（propsSchema/events/functions）
├── types.ts      # props/state 类型
├── style.scss    # 样式（收敛在根 className 内）
└── doc.md        # 组件文档
```

平台运行时加载 React 16 + antd，组件遵循平台契约（默认导出 React 组件、经 neo-register 注册、样式隔离）。

- `generate uicomponent`：纯本地生成源码骨架，不依赖 neo-cmp-cli。
- `deploy uicomponent`：**自研 esbuild 构建 + multipart 上传**。发布时打包源码、套 neoRequire 包裹、复用 neo-register 注册、生成元数据与源码 zip，multipart 上传 `saveOrUpdateComponent`，随后清理产物（用户目录内始终只有源码）。
- `retrieve uicomponent`：**纯 REST**。查询组件 → 下载源码 zip（codeLib）→ 解压只保留 `src/components/<name>` 源码回写本地。

### 依赖 neo-cmp-cli 的现状：已完全去除 ✅

| 命令 | 是否依赖 neo-cmp-cli |
|---|---|
| `generate uicomponent` | ❌ 纯本地脚手架 |
| `deploy uicomponent` | ❌ 自研 esbuild 构建 + multipart 上传 |
| `retrieve uicomponent` | ❌ 纯 REST（下载 codeLib zip 解压） |

平台运行时契约见 [docs/uicomponent-contract.md](docs/uicomponent-contract.md)。

### 自研构建工作区（build workspace，仅 deploy 使用）

neo 在全局区 `~/.neocrm-cli/builder/` 维护一个**自有**构建工作区（首次 `npm install` 需要被打进产物但不由平台提供的依赖：`neo-register`、`neo-open-api`、`echarts`、`moment` 等，之后复用）。`deploy uicomponent` 时：

1. 把 `uicomponents/<name>/` 源码拷入工作区
2. 生成 register 入口（`neo-register`），用 **esbuild** 打包：平台提供的依赖（react/react-dom/antd/lodash/… 见 contract §2.1）标 `external`，其余打进产物
3. 产物套 neoRequire 包裹；scss 经 sass 编译抽取为 CSS
4. 从 `model.ts` 生成元数据；源码打包 zip
5. multipart 上传 `saveOrUpdateComponent`（`assetFile`/`modelAssetFile`/`cssAssetFile`/`codeLibFile` + `component` JSON）
6. 清理构建产物

凭证复用 `neo login` 的登录。**无需安装 neo-cmp-cli。**

---

## 已确认的平台 API（P0）

| 元数据 | 操作 | 接口 |
|---|---|---|
| 对象 | 创建 | `POST /rest/metadata/v3.1/xobjects/` |
| 对象 | 更新 | `PATCH /rest/metadata/v3.1/xobjects/{apiKey}` |
| 对象 | 列表 | `GET /rest/metadata/v2.0/xobjects/filter?custom=true&active=true` |
| 字段 | 创建 | `POST /rest/metadata/v3.1/xobjects/{apiKey}/items` |
| 字段 | 更新 | `PATCH /rest/metadata/v3.1/xobjects/{apiKey}/items/{itemApiKey}` |
| 字段 | 列表 | `GET /rest/metadata/v2.0/xobjects/{apiKey}/items` |
| NEX | 列表/读写/发布 | `GET|POST /rest/metadata/v3.1/nex/codes/…` |
| 代码包 | 查询/建包/上传/安装 | `GET|POST /rest/metadata/v2.0/scripts/packages…` |

> 写入 API 需要租户开启「Metadata API」功能点；沙盒默认可用，生产需申请开通。

---

## 平台能力检索（不依赖 MCP）

`neo platform search` 通过当前项目（或显式 `--project-root`）解析 `neo-project.json` 和项目隔离凭证，适合只加载全局 Skills、但不能读取项目级 MCP 配置的 Agent：

```bash
neo platform search --query "NeoCRM 审批流支持哪些能力？" --json

# Agent 不在项目目录时必须使用用户确认的绝对路径
neo platform search \
  --project-root "/absolute/path/to/neocrm-project" \
  --query "NeoCRM 审批流支持哪些能力？" \
  --json
```

默认知识库别名为 `platform-capabilities`；文档/文件问答使用 `--knowledge-base file-answer`。命令输出 JSON，包含 `context.root`、`context.projectId`、`context.tenant`、`context.environment` 与 API `result`；不输出 OAuth 凭证，也不需要 MCP 配置。

## NeoCRM 平台 MCP

`neocrm-cli` 不再提供本地 `neocrm-mcp` server 或本地工具注册表。`neo init` 生成的 CodeBuddy 项目级 `.mcp.json` 会启动 `bin/platform-mcp.js`，以当前项目 `neo login` 的有效凭证连接服务端 NeoCRM 平台 MCP。

服务端 MCP 的工具、参数、读写权限和发布节奏由平台维护。Agent 应通过已连接服务执行 `tools/list` 获取实际能力，不能假设旧本地工具名仍存在。CLI 的 source-driven 生成、检索、部署和平台知识检索仍通过 `neo` 命令提供。

### 配置（CodeBuddy 项目级 MCP）

`neo init` 会在项目根生成 CodeBuddy 项目级配置 `.mcp.json`，并注册 `neocrm-platform`。CodeBuddy 会在首次连接项目级 MCP 时向用户请求批准。

```json
{
  "mcpServers": {
    "neocrm-platform": {
      "type": "stdio",
      "command": "/absolute/path/to/node",
      "args": ["/absolute/path/to/neocrm-cli/bin/platform-mcp.js"],
      "env": {
        "NEOCRM_PROJECT_ROOT": "/abs/path/to/project"
      },
      "description": "NeoCRM 平台 MCP。使用当前 Neo 项目的 neo login 登录态。"
    }
  }
}
```

- 代理在调用时读取当前项目的 `neo login` 登录态，自动刷新短期 access token，并发送 `Authorization` 与 `X-CRM-Instance` 请求头。token 不会进入 `.mcp.json` 或项目版本库。
- 代理根据登录环境选择端点：`production` 和 `sandbox` 使用 `https://mcp-platform.xiaoshouyi.com/crm/mcp?scope=entity&detail=slim`；`custom` 使用 `https://mcp-platform-dev.xiaoshouyi.com/crm/mcp`。
- 配置使用 Node 和随已安装 CLI 分发的 `bin/platform-mcp.js` 绝对路径，因此项目不需要本地 `node_modules`。
- Kiro、Cursor 或其他 Agent 不会自动读取 CodeBuddy 的项目配置。用户可让对应 Agent 将 `.mcp.json` 中的 `mcpServers.neocrm-platform` 合并到其原生 MCP 配置，且不得覆盖已有 MCP 服务。

### 查询 API（供参考）

| 操作 | 接口 |
|---|---|
| SQL/XOQL 查询 | `GET /rest/data/v2/query?q=<encodedSql>`（结果在顶层 `result`：`{ totalSize, count, records }`） |
| 创建业务类型 | `POST /rest/metadata/v3.1/xobjects/{apiKey}/busiTypes` |

---

## 开发

从源码构建 / 本地调试：

```bash
cd neocrm-cli
npm install
npm run build   # 编译到 dist/
npm link        # 将 neo 命令软链到全局（开发调试用）

npm run dev     # tsc watch（开发时热编译）
npm run clean   # 清理 dist/
```

发布到 npm 后也可 `npm i -g neocrm-cli`（提供正式命令 `neo`，并在 `neo init` 时生成服务端平台 MCP 代理配置）。

打包分发（详见 `scripts/`）：

```bash
bash scripts/build-pkg.sh darwin-arm64   # 生成已签名 macOS arm64 .pkg（dist-pkg/）
bash scripts/build-pkg.sh darwin-x64     # 生成已签名 macOS x64 .pkg
bash scripts/pack-zip.sh                 # 生成按平台的离线 zip 安装包
bash scripts/build-win-exe.sh             # 生成 Windows x64 NSIS .exe 安装向导
bash scripts/build-skills-zip.sh         # 生成技能 skills.zip（dist-skills/）
```

macOS `.pkg` 默认从本机钥匙串发现目标 Team 的 Developer ID Application/Installer identity，并为 payload 和 Installer 签名请求 Apple 受信任时间戳。仅当同类存在多个不同的有效通用名时，可在单次构建中传入精确覆盖：`NEOCRM_CODESIGN_IDENTITY='Developer ID Application: IngageApp Co., Ltd (H6ZB4HEYA3)' NEOCRM_INSTALLER_IDENTITY='Developer ID Installer: IngageApp Co., Ltd (H6ZB4HEYA3)' bash scripts/build-pkg.sh darwin-arm64`。该流程只做本地签名，不执行 notarization 或 stapling，不能保证所有 Gatekeeper 策略放行。

调试环境变量：`NC_DEBUG=1` 打印完整错误堆栈。
